import { S3Client, GetObjectCommand, PutObjectCommand } from '@aws-sdk/client-s3';
import { Response } from 'node-fetch';

export const handler = async(event) => {
    // basic proof of life
    // console.log('this is our event', event);
    
    // create a s3Client connection
    const s3Client = new S3Client({region: "us-west-2"});
    // const Bucket = 'rkgallaway-numbers';
    // need some parameters to use the "get" command
    const params = {
        // Key: event.Records[0].s3.object.key,
        Key: 'numbers.json',
        Bucket: 'rkgallaway-numbers',
    };
    
    console.log('new event info', params);
    
    let myJson;
    try {
        myJson = await s3Client.send(new GetObjectCommand(params));
        const response = new Response(myJson.Body);
        myJson = await response.json();
    }catch(e){
        console.log("Handler Event", JSON.stringify(event, undefined, "  "));
    }
    
    console.log('this is my json', myJson);
    
    // const { numberOne, numberTwo } = event;
    // const result = numberOne + numberTwo;
    // console.log('my result', result);
    // TODO implement
    const response = {
        statusCode: 200,
        // send valid json (a number is valid json)
        body: 42,
    };
    return response;
};
